#!/usr/bin/env bash
set -euo pipefail
python -m src.main stop || true